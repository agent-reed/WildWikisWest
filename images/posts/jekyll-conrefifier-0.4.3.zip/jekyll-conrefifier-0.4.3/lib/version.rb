module JekyllConrefifier
  VERSION = '0.4.3'
end
