---
title: This is very {{ site.data.conrefs.product_type }}
---

Some page.
