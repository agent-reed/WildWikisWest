---
title: This is {{ site.data.conrefs.bold_title }}
layout: article
---

Oh my my.
